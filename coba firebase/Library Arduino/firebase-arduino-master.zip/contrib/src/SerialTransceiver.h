#include <string>

#include "modem/SerialTransceiver.h"
#include "modem/db/DatabaseProtocol.h"

// Bring them into the base namespace for easier use in arduino ide.
using firebase::modem::SerialTransceiver;
using firebase::modem::DatabaseProtocol;
