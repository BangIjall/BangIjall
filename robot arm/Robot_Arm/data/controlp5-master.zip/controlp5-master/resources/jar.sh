cd $HOME/Documents/workspace/controlp5/bin
jar cf ../test/controlP5.jar .
cp ../test/controlP5.jar $HOME/Documents/Processing3/libraries/controlP5/library
echo "controlP5 compiled on $(date)"
