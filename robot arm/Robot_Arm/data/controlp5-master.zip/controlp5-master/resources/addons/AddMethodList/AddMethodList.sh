
javac -cp .:../../../distribution/tmp/controlP5/library/controlP5.jar AddMethodList.java
java -cp .:../../../distribution/tmp/controlP5/library/controlP5.jar:$HOME/Documents/workspace/libs/core.jar AddMethodList $HOME/Documents/workspace/controlp5/examples/controllers/ControlP5accordion/
