<?php
// $conn = mysqli_connect("localhost","u665944158_siagabanjir","WebsiteAndroid2022","u665944158_siagabanjir");
$conn = mysqli_connect("localhost", "siagabanjir", "WebsiteAndroid2022", "u665944158_siagabanjir");
if (isset($_GET["p"])) {
    $p = $_GET["p"];
    if ($p == 'realtime') {
        $allcurah = mysqli_query($conn, "SELECT value1, value2,date_format(reading_time,'%d-%m-%Y %H:%i:%s') as waktu from curah order by id desc");
        $alllaju = mysqli_query($conn, "SELECT value1, value2,date_format(reading_time,'%d-%m-%Y %H:%i:%s') as waktu from laju order by id desc");
        $alllevel = mysqli_query($conn, "SELECT value1, value2,date_format(reading_time,'%d-%m-%Y %H:%i:%s') as waktu from level order by id desc");
        $rallcurah = mysqli_fetch_row($allcurah);
        $ralllaju = mysqli_fetch_row($alllaju);
        $ralllevel = mysqli_fetch_row($alllevel);
        // $nilaicurah = $rallcurah[0];
        // $statuscurah = $rallcurah[1];
        $waktucurah = $rallcurah[2];
        // $nilailaju = $ralllaju[0];
        // $statuslaju = $ralllaju[1];
        $waktulaju = $ralllaju[2];
        // $nilailevel = $ralllevel[0];
        // $statuslevel = $ralllevel[1];
        $waktulevel = $ralllevel[2];
        $data = array('waktucurah' => $waktucurah, 'waktulaju' => $waktulaju, 'waktulevel' => $waktulevel);
        echo json_encode($data);
    } else if ($p == 'tabel') {
        $q = $_GET['q'];
        if ($q == 'level') {
            $param = mysqli_query($conn, "SELECT value1,value2,date_format(reading_time,'%d-%m-%Y %H:%i:%s') as waktu from $q");
        } elseif ($laju = 'laju') {
            $param = mysqli_query($conn, "SELECT WaterFlow1,WaterFlow2,WaterFlow3,WaterFlow4,date_format(reading_time,'%d-%m-%Y %H:%i:%s') as waktu from $q");
        } elseif ($q == 'curah') {
            $param = mysqli_query($conn, "SELECT value1,Parameter_Hujan,date_format(reading_time,'%d-%m-%Y %H:%i:%s') as waktu from $q");
        }
        $data = array();
        while ($row = mysqli_fetch_assoc($param)) {
            $data['data'][] = $row;
        }
        echo json_encode($data, JSON_PRETTY_PRINT);
    } else if ($p == 'grafik') {
        $q = $_GET['q'];
        $time = mysqli_query($conn, "SELECT date_format(reading_time, '%H:%i') as waktu FROM $q order by id asc limit 20");
        $param = mysqli_query($conn, "SELECT value1 FROM $q order by id asc");
        $rows = array();
        $rows['param'] = 'time';
        while ($t = mysqli_fetch_array($time)) {
            $rows['data'][] = $t['waktu'];
        }
        $rows1 = array();
        $rows1['param'] = $q;
        while ($qq = mysqli_fetch_array($param)) {
            $rows1['data'][] = $qq['value1'];
        }
        $gg = array();
        array_push($gg, $rows);
        array_push($gg, $rows1);
        echo json_encode($gg, JSON_NUMERIC_CHECK);
    }
} else {
    echo 'p not defined';
}
